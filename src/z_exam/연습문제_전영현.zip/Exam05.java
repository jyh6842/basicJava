package z_exam;

public class Exam05 {
	public static void main(String[] args) {
/*		[5-1] 다음은 배열을 선언하거나 초기화한 것이다. 잘못된 것을 고르고 그 이유를 설명
		하시오.*/
//		a. int[] arr[];// OK
//		b. int[] arr = {1,2,3,}; //OK
/*				int[] arr = {1,2,3,};
				for (int i = 0; i < arr.length; i++) {
					System.out.println(arr[i]);
				}*/
//		c. int[] arr = new int[5];// OK
//		d. int[] arr = new int[5]{1,2,3,4,5}; // 뒤에 초기화 값을 쓰면 안됨
//		e. int arr[5]; // 배열의 크기가 지정되어 있으나 초괴화를 하지 않았음
//		f. int[] arr[] = new int[3][]; // OK
		
		
		/*[5-2] 다음과 같은 배열이 있을 때, arr[3].length의 값은 얼마인가?
				int[][] arr = {
				{ 5, 5, 5, 5, 5},
				{ 10, 10, 10},
				{ 20, 20, 20, 20},
				{ 30, 30}
				};
		*/
	}//main
}
